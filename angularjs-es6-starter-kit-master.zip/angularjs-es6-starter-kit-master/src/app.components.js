// making sure my files load so we need to import each module here.
import './components/header';
import './components/home';
import './components/user';
