export default [
	{
		name: 'home',
		url: '/',
		component: 'home'
	},
	{
		name: 'user',
		url: '/user',
		component: 'user'
	}
];
