import controller from './user.controller';
import template from './user.html';

export default {
	controller: controller,
	template: template
}
