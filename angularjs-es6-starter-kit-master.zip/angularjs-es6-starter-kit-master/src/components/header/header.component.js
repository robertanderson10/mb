import template from './header.html';

export default {
	template: template
};
