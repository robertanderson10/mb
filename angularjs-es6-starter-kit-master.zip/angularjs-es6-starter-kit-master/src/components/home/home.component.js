import template from './home.html';
import controller from './home.controller';

export default {
	template: template,
	controller: controller
};
